import java.io.*;
import java.net.*;
import java.util.*;

public class Client {

	public static ArrayList<Node> linkNode = new ArrayList<Node>();
	private static int sourceNode;
	static int destPort;
	static int destNode;
	static String sourceHost;
	static String destHost;
	private static int sourcePort;
	static int numberNodes;
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

	public static ArrayList<Node> getLinkNode() {
		return linkNode;
	}
	public Client(int nodeID, String itcFile) throws IOException {
		assignFromFile(itcFile);
		
		// Gets the port number of the node you initially set
		for (Node n : linkNode) {
			numberNodes++;
			if (n.getNodeID() == nodeID) {
				sourceNode = n.getNodeID();
				sourcePort = n.getPortNumber();
				sourceHost = n.getHostName();
			}
		}
		startServer(sourcePort);
		startClient();
	}

	public static InetAddress getSourceAddress(Socket s) {
		
		InetAddress sourceAddress;
		
		
		return null;
	}
	public void assignFromFile(String itcFile) throws FileNotFoundException {

		// reads from the file you initially set in the running prompt
		Scanner docScan = new Scanner(new File(itcFile + ".txt"));
		String data;
		// final Node NODE;

		// reads each line of the text files
		while (docScan.hasNextLine()) {
			data = docScan.nextLine();

			String[] word = data.split(" ");

			// sets each variable of the documents to a Node
			final Node NODE = new Node(Integer.parseInt(word[0]), word[1], Integer.parseInt(word[2]),
					Integer.parseInt(word[3]), Integer.parseInt(word[4]), Integer.parseInt(word[5]));
			linkNode.add(NODE);
		}
		docScan.close();
	}

	public void startClient() {
		(new Thread() {
			@Override
			public void run() {
				try {
					
					// Gets input from user
					BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
					
					DatagramSocket socket = new DatagramSocket();
					
					//creates a writer that writes out to the socket that you set
					//BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

					// gets input from user and sends it to the buffered reader
					
					String message = "";
					while(true) {
						
						try {
							
							System.out.print("Enter message: ");
						message = inFromUser.readLine();
						
						//prompts for dest node to set for later
						System.out.print("Enter destination node: ");
						destNode = Integer.parseInt(reader.readLine());
						
						
						for(Node n : linkNode) {
							if(destNode == n.getNodeID()) {
								destPort = n.getPortNumber();
								destHost = n.getHostName();
							}
						}
						
						}catch(IOException ioe) {
							System.err.println("INCORRECT FORMAT");
						}
						
						int length;
						
						if(message == null) break;
						
						message = message + "\n";
						length = message.length();
						byte[] bbuf = message.getBytes();
						
						//DatagramPacket msg = new DatagramPacket(new byte[0], 0, InetAddress.getByName(destHost), destPort);
						DatagramPacket msg = new DatagramPacket(new byte[0], 0, InetAddress.getLocalHost(), destPort);

						msg.setData(bbuf);
						msg.setLength(length);
												
						try {
							TransportLayer transportData = new TransportLayer(sourceNode, sourcePort, destNode, destPort, message, msg);
							NetworkLayer nl = new NetworkLayer(sourceNode, destNode, msg);
							LinkLayer dataLink = new LinkLayer(sourceNode, destNode, msg);
							try {
								transportData.sendData(destNode, message);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							//socket.connect(InetAddress.getByName(destHost), destPort);
							socket.send(msg);
							
						} catch(IOException ioe) {
							System.err.println("PACKET DROPPED");
							return;
						} //socket.close(); figure where to close the socket
						
					}

				} catch (UnknownHostException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} 
			}
		}).start();
	}

	public static void startServer(int port) {
		(new Thread() {
			@Override
			public void run() {
				
				DatagramSocket dSocket;
				int bufSize = 512;
				DatagramSocket[] dSockets = new DatagramSocket[numberNodes];
							
				try {
					
					// creates a server on the port of the nodeID you set in the beginning prompt
					//ss = new ServerSocket(port);
					dSocket = new DatagramSocket(port);
					
				} catch(SocketException se) {
					System.err.println("PORT: " + port + " IN USE.");
					return;
				}
				
				DatagramPacket msg = new DatagramPacket(new byte[bufSize], bufSize);
				
				while(true) {
					try {
					msg.setLength(bufSize);
					dSocket.receive(msg);
					System.out.println("MESSAGE FROM <" + msg.getAddress().getHostAddress() + "," + msg.getPort() + ">");
				} catch(SocketTimeoutException ste) {
					System.err.println("response timed out");
					continue;
				} catch(IOException ioe) {
					System.err.println("Could not receive message...");
					break;
				}
					
					String str = new String(msg.getData(), 0, msg.getLength());
					System.out.println(str);
					
				}
				dSocket.close();
					// accepts that socket port and runs the server
					//Socket s = ss.accept();

					// gets input from the client
					/*BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
					String line = null;
					
					// Reads the input from the client
					line = in.readLine();
					
					//displays the client and the local IP/port for debugging purposes
					System.out.println(line);
					System.out.println(s.getLocalSocketAddress());
				} catch (IOException e) {
					e.printStackTrace();
				}*/
			} 
		}).start();
	}
}
