import java.util.*;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;

public class NetworkLayer {
	int sourceNode, destNode;
	String message;
	int numberNodes;
	DatagramPacket msg;
	
	final int TTL = 1000;
	
	/**values for setting up adjMatrix***/
	int[] nbrOneArr;
	int[] nbrTwoArr;
	int[][] distMatrix;
	/************************************/
	
	PriorityQueue<Integer> dcNodes = new PriorityQueue<Integer>();
	PriorityQueue<Integer> connectedNodes = new PriorityQueue<Integer>();
	
	
	private PriorityQueue<pqNode> nodeQ;
	private Set<Integer> settled;
	private int[] distances;
	static ArrayList<Node> nodeList;
	private ArrayList<Integer> previous;
	
	
	
	public NetworkLayer(int sourceNode, int destNode, DatagramPacket msg) {
		this.sourceNode = sourceNode;
		this.destNode = destNode;
		this.msg = msg;
	}
	
	public NetworkLayer() {
		
	}

	public void routingTable() throws SocketException {
		/*****Declares total number nodes*******/
		for (Node n : Client.linkNode)
			numberNodes++;
		
		/*****Sets the sizes of the arrays********/
		nbrOneArr = new int[numberNodes+1];
		nbrTwoArr = new int[numberNodes+1];
		distMatrix = new int[numberNodes+1][numberNodes+1];
		
		/*****Sets the values of the arrays********/
		nodeList = new ArrayList<Node>();
		for(Node n : Client.linkNode) {
			nodeList.add(n);
			nbrOneArr[n.getNodeID()-1] = n.getNodeOne()-1;
			nbrTwoArr[n.getNodeID()-1] = n.getNodeTwo()-1;
		}
		
		List<Edge> edges = new ArrayList<>();
		for(int i = 0; i < numberNodes; i++) {
			edges.add(new Edge(i, nbrOneArr[i], 1));
			edges.add(new Edge(i, nbrTwoArr[i], 1));
		}
		

		Graph g = new Graph(edges, numberNodes);
		Dijkstra d = new Dijkstra();
		
		
		Dijkstra.shortestPath(g, sourceNode-1, destNode-1);
		
		System.out.println();
	
		int node = 0;
		
		while(!Dijkstra.addPath.isEmpty()) {
				try {
					node = Dijkstra.addPath.poll();
					 if(isConnected(destNode, nodeList.get(destNode - 1).getPortNumber())) {
						 System.out.println("The destination node: " + destNode + " is not connected... try again.");
							break;
							
						}
					 else if(!isConnected(node, nodeList.get(node - 1).getPortNumber())) {
						 connectedNodes.add(node);
							if(Dijkstra.addPath.contains(node)) {
								continue;
							}
						System.out.println("Node: " + node + " is connected.");

					} else {
						System.out.println("Node: " + node + " is not connected.");
						dcNodes.add(node);
						
				
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		if(dcNodes.size() > 0)
			recalcRoute(dcNodes);
	
		LinkLayer ll = new LinkLayer(sourceNode, destNode, msg);
	
		ll.getPath(connectedNodes);
		
	}
	
	public void connected(int nodeID){
		
		connectedNodes.add(nodeID);
		
	}
	
	public void disconnected(int nodeID) {
		
		dcNodes.add(nodeID);
	}
	
	
	public PriorityQueue<Integer> recalcRoute(PriorityQueue<Integer> dcNodes) {
	
		System.out.println();
		System.out.println("**********************************");
		System.out.println("****    Recalcating Route     ****");
		System.out.println("**********************************");
		ArrayList<Edge> edges = new ArrayList<>();

		while(!dcNodes.isEmpty()) {
			int nodeIndex = dcNodes.poll();
			for(Node n : nodeList) {
				if(n.getNodeID() != nodeIndex) {
					edges.add(new Edge(n.getNodeID() -1, n.getNodeOne() - 1, 1));
					edges.add(new Edge(n.getNodeID() -1, n.getNodeTwo() -1, 1));
				} else
					continue;
				
			}
		}

		Graph g = new Graph(edges, numberNodes);
		Dijkstra d = new Dijkstra();
		
		
		Dijkstra.shortestPath(g, sourceNode-1, destNode-1);
		
		return dcNodes;
		
		
	}
	public boolean isConnected(int nodeID, int port) throws IOException {
		
		ServerSocket ss = null;
		DatagramSocket ds = null;
		
		try {
			ss = new ServerSocket(port);
			ss.setSoTimeout(TTL);
			ss.setReuseAddress(true);
			ds = new DatagramSocket(port);
			ds.setSoTimeout(TTL);
			ds.setReuseAddress(true);
			return true;
		} catch(IOException e) {
		} finally {
			if(ds != null) {
				ds.close();
			}
			
			if(ss != null) {
				try {
					ss.close();
				} catch(IOException e) {
					
				}
			}
		}
		return false;
	}
	
}

class Edge {
	int src, dest, weight;
	
	public Edge(int src, int dest, int weight) {
		this.src = src;
		this.dest = dest;
		this.weight = weight;
	}
};

class pqNode implements Comparator<pqNode> {
	
	public int node;
	public int weight;
	
	public pqNode() {
		
	}
	
	public pqNode(int node, int weight) {
		
		this.node = node;
		this.weight = weight;
	}
	
	@Override
	public int compare(pqNode node1, pqNode node2) {
		if(node1.weight < node2.weight)
			return -1;
		if(node1.weight > node2.weight)
			return 1;
		
		return 0;
	}
}

class Graph {

	List<List<Edge>> adjList = null;
	
	Graph(List<Edge> edges, int numberNodes){
		
		for(Node n : Client.linkNode)
			numberNodes++;
		
		adjList = new ArrayList<>(numberNodes*2);
		
		for(int i = 0; i < numberNodes; i++)
			adjList.add(i, new ArrayList<>());
		
		for(Edge edge : edges) {
			adjList.get(edge.src).add(edge);
		}
	}
}



class Dijkstra {
	
	public static NetworkLayer nl = new NetworkLayer();
	public static PriorityQueue<Integer> addPath = new PriorityQueue<Integer>();
	
	private static void printRoute(int prev[], int i) {
		
		if(i < 0)
			return;
		
		printRoute(prev, prev[i]);
		System.out.print((i + 1) + " -> ");
		
		int node = i + 1;
		addPath.add(node);
	}
	
	public static void shortestPath(Graph g, int sourceNode, int destNode) {
		
		int numNodes = 0;
		for(Node n : Client.linkNode)
			numNodes++;
		
		PriorityQueue<pqNode> nodeQ = new PriorityQueue<>((lhs, rhs) -> lhs.weight - rhs.weight);
		
		nodeQ.add(new pqNode(sourceNode, 0));
		
		List<Integer> distance = new ArrayList<>(Collections.nCopies(numNodes*2, Integer.MAX_VALUE));
		
		distance.set(sourceNode, 0);
		
		boolean[] visited = new boolean[numNodes];
		visited[sourceNode] = true;
		
		int[] previous = new int[numNodes];
		previous[sourceNode] = -1;
		
		while(!nodeQ.isEmpty()) {
			
			pqNode nNode = nodeQ.poll();
			
			int u = nNode.node;
			
			for(Edge edge : g.adjList.get(u)) {
				int v = edge.dest;
				int weight = edge.weight;
				
				if(!visited[v] && (distance.get(u) + weight) < distance.get(v)) {
					distance.set(v, distance.get(u) + weight);
					previous[v] = u;
					nodeQ.add(new pqNode(v, distance.get(v)));
				}
			}
			
			visited[u] = true;
		}
		
		for(int i = 0; i < numNodes; ++i) {
			if(i == destNode && distance.get(i) < Integer.MAX_VALUE) {
				System.out.print("Path from " + (sourceNode +1) + " to " + (i + 1) + " is: [");
				printRoute(previous, i);
				System.out.println("]");
			} 
		}
	}
}
