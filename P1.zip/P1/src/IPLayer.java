
public class IPLayer {

	String message;
	int neighborOne, neighborTwo;
	
	public IPLayer(String message, int neighborOne, int neighborTwo) {
		super();
		this.message = message;
		this.neighborOne = neighborOne;
		this.neighborTwo = neighborTwo;
	}
	
	
	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public int getNeighborOne() {
		return neighborOne;
	}


	public void setNeighborOne(int neighborOne) {
		this.neighborOne = neighborOne;
	}


	public int getNeighborTwo() {
		return neighborTwo;
	}


	public void setNeighborTwo(int neighborTwo) {
		this.neighborTwo = neighborTwo;
	}


	// Need to rework these to add to a DatagramPacket to create for a UDP application
	public void sendData(int destNode, int neighborOne, int neighborTwo, String message){

			message = neighborOne + " " + neighborTwo + " " + message;
		System.out.println(message);
	}
	
}
