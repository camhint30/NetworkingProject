import java.io.*;
import java.util.*;

public class Node implements Comparable<Node>{

	private String hostName;
	private int nodeID, portNumber, nodeOne, nodeTwo, mtuBytes;
	int distance = Integer.MAX_VALUE;
	Map<Node, Integer> adjNodes = new HashMap<>();
	LinkedList<Node> shortestPath = new LinkedList<>();
	
	public void addDest(Node destination, int distance) {
		adjNodes.put(destination, distance);
	}
	
	/*public Node(int nodeID) {
		this.nodeID = nodeID;
	}*/
	
	
	public Node(int nodeID, int distance) {
		this.distance = distance;
		this.nodeID = nodeID;
	}
	
	public Node(int nodeID, String hostName, int portNumber, int nodeOne, int nodeTwo, int mtuBytes) {
		super();
		this.nodeID = nodeID;
		this.hostName = hostName;
		this.portNumber = portNumber;
		this.nodeOne = nodeOne;
		this.nodeTwo = nodeTwo;
		this.mtuBytes = mtuBytes;
	}
	
	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getNodeID() {
		return nodeID;
	}

	public void setNodeID(int nodeID) {
		this.nodeID = nodeID;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public int getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(int portNumber) {
		this.portNumber = portNumber;
	}

	public int getNodeOne() {
		return nodeOne;
	}

	public void setNodeOne(int nodeOne) {
		this.nodeOne = nodeOne;
	}

	public int getNodeTwo() {
		return nodeTwo;
	}

	public void setNodeTwo(int nodeTwo) {
		this.nodeTwo = nodeTwo;
	}

	public int getMtuBytes() {
		return mtuBytes;
	}

	public void setMtuBytes(int mtuBytes) {
		this.mtuBytes = mtuBytes;
	}
	
	
	@Override
	public String toString() {
		return "ReadData [nodeID=" + nodeID + ", hostName=" + hostName + ", portNumber=" + portNumber + ", nodeOne=" + nodeOne
				+ ", nodeTwo=" + nodeTwo + ", mtuBytes=" + mtuBytes + "]";
	}

	@Override
	public int compareTo(Node otherNode) {
		
		return Integer.compare(distance, otherNode.getDistance());
	}

	public void setAdjNodes(Map<Node, Integer> adjNodes) {
		this.adjNodes = adjNodes;
	}
	public Map<Node, Integer> getAdjNodes() {
		return adjNodes;
	}

	public LinkedList<Node> getShortestPath() {
		return shortestPath;
	}
	public void setShortestPath(LinkedList<Node> shortPath) {
		this.shortestPath = shortPath;
		
	}

}
	