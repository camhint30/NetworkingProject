
public class Neighbor {

}
