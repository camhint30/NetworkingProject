import java.util.*;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;

public class LinkLayer {
	float probability;
	int sourceNode;
	DatagramPacket msg;
	String header;
	int destNode;
	int sourcePort;
	int destPort;
	String dropped = "MESSAGE DROPPED";
	ArrayList<Node> nodeList = new ArrayList<Node>();
	
	public LinkLayer(int sourceNode, int destNode,  DatagramPacket msg) {
		this.sourceNode = sourceNode;
		this.msg = msg;

		this.destNode = destNode;
	}
	
	public LinkLayer(String header) {
		this.header = header;
	}
	
	public LinkLayer() {
		
	}
	

	public void updateHeader(DatagramPacket msg) {
		
		String header = new String(msg.getData());
		String sourceIP = "";
		String destIP = "";
		
		for(Node n : Client.linkNode) {
			if(n.getNodeID() == sourceNode) {
				sourceIP = n.getHostName();
			}
			if(n.getNodeID() == destNode) {
				destIP = n.getHostName();
			}
		}
		
		header = sourceIP + " " + destIP + " " + header;
		msg.setData(header.getBytes());
	}
	
	public String removeHeader(DatagramPacket msg) {
		
		String sourceIP = "";
		String destIP = "";
		
		for(Node n : Client.linkNode) {
			if(n.getNodeID() == sourceNode) {
				sourceIP = n.getHostName();
			}
			if(n.getNodeID() == destNode) {
				destIP = n.getHostName();
			}
		}
		
		String str = new String(msg.getData());
		String tempStr = new String(sourceIP + " " + destIP);
		
		str = str.replaceAll(tempStr, "");
		System.out.println(str);
		msg.setData(str.getBytes());
		
		return str;
	}
    public int recalcChecksum(String header) {

        int maxSize = 0;
        int length = msg.getLength();
        int transmissionBytes;
        
        // set the maximum size of the data with the MTU's from the file
        for (Node node : Client.linkNode) {
        	nodeList.add(node);
            if (sourceNode == node.getNodeID()) {
                maxSize = node.getMtuBytes();
                transmissionBytes = maxSize;
            }
        }

        // array to hold the max size for the data being sent
        int strdata[] = new int[maxSize];

        // array to hold the max size for the compliment of the data
        int complimentData[] = new int[maxSize];

        int numBits = 0;
        int checkSum = 0, i = 0;
        String strLength = new String(msg.getData());
       
		for(byte b : msg.getData()) {
			
			strdata[i] = b;
		}
		
		i = 0;
		
		String str = new String(msg.getData());
		
		System.out.println(str);
		
        // creating the checksum for the length of data in the message
        for (i = 0; i < msg.getLength(); i++) {
        	
 
            numBits = (int)(Math.floor(Math.log(strdata[i]) / Math.log(2))) + 1;

            // compliments the checksum
            complimentData[i] = ((1 << numBits) - 1) ^ strdata[i];

            // adding the complimented data
            checkSum += complimentData[i];
        }


        numBits = (int)(Math.floor(Math.log(checkSum) / Math.log(2))) + 1;  
        checkSum = ((1 << numBits) - 1) ^ checkSum; 
   

        return checkSum;
    }
    
    public void getPath(PriorityQueue<Integer> connectedNodes) {
    	
    	PriorityQueue<Integer> ports = new PriorityQueue<>();

    	for(Node n : Client.linkNode)
    		nodeList.add(n);
    	
    	
    	while(!connectedNodes.isEmpty()) {
    		int topNode = connectedNodes.peek();
    		
    		for(Node n : nodeList) {
    			if(topNode == n.getNodeID()) {
    				ports.add(n.getPortNumber());
    				connectedNodes.poll();
    			}
    		}
    	}
  
    	updateHeader(msg);
    	String str = new String(msg.getData());
    	
    	try {
			pushMessage(ports);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
    
    public void pushMessage(PriorityQueue<Integer> ports) throws IOException {
    	
    	DatagramSocket socket = new DatagramSocket();
    	
    	destPort = 0;
    	for(Node n : nodeList) {
    		if(destNode == n.getNodeID())
    			destPort = n.getPortNumber();
    		if(sourceNode == n.getNodeID())
    			sourcePort = n.getPortNumber();
    	}
    	
    	while(!ports.isEmpty()) {
    		int topPort = ports.poll();
    		DatagramPacket alertPacket = new DatagramPacket(new byte[0], 0, InetAddress.getLocalHost(), topPort);
    		for(Node n : nodeList) {
    			if(n.getPortNumber() == topPort && topPort != destPort && topPort != sourcePort) {
    				String str = "MESSAGE RECEIVED>>FORWARDING TO NEXT NEIGHBOR>>";
    				alertPacket.setData(str.getBytes());
    				alertPacket.setLength(str.length());
    				try {    	
						socket.send(alertPacket);
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			} else if(topPort == destPort) {
    				garbler(msg.getData());
    				
    				TransportLayer tLayer = new TransportLayer();
				//	removeHeader(msg);
       				String str = new String(msg.getData());
       				
  
       				System.out.println();
       				
    		    	int recCheck = recalcChecksum(str);
    		    	int sendCheck = tLayer.checkSum;
    		    	
    		    	System.out.println(recCheck + " " + sendCheck);
    				if(sendCheck != 0) {
    					System.out.println("Checksum failure...");
    					msg.setData(dropped.getBytes());
    					socket.send(msg);
    					break;
    				}
    				else if (sendCheck == 0){
    					System.out.println("Checksum succeeded.");
    					socket.send(msg);
    					break;
    					
    				}
    			}
    		}
    	}
    }
	public byte[] garbler(byte[] data) throws FileNotFoundException {
		byte[] tempData = data;
		
		Random rand = new Random();
		probability = rand.nextFloat();
	
		if(probability < .15) {
			System.out.println("Message Garbled...");
			if (tempData.length > 0) { // Determine the size of the packet
				int randomLocationToGarble = rand.nextInt(data.length);
				for(byte b : data)
					System.out.print(b + " ");
				System.out.println();
				tempData[randomLocationToGarble] = (byte)(~((int)tempData[randomLocationToGarble])); 
				for(byte b : tempData)
					System.out.print(b + " ");
				System.out.println();
				return tempData;
			}
		}

		return data;
	}
	
	public boolean isGarbled(float probability) {
	
		if(probability < .15)
			return true;

		return false;
	}
	
}
