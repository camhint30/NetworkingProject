import java.io.*;
import java.nio.ByteBuffer;
import java.util.Scanner;
import java.util.zip.Adler32;
import java.net.*;

public class TransportLayer {

	int destPort, sourcePort, sourceNode, destNode, transmissionBytes;
	String message;
	DatagramPacket msg;
	int checkSum;
	ByteBuffer header;
	public TransportLayer() {

	}

	public TransportLayer(int sourceNode, int sourcePort, int destNode, int destPort, String message, DatagramPacket msg) {
		super();
		this.sourceNode = sourceNode;
		this.sourcePort = sourcePort;
		this.destNode = destNode;
		this.destPort = destPort;
		this.message = message;
		this.msg = msg;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	private String createHeader(String message) throws SocketException {
		byte srcPort;
		byte dPort;
		byte[] ports = new byte[2];
		srcPort = (byte) sourcePort;
		dPort = (byte) destPort;
		ByteBuffer header;
		
		ports[0] = srcPort;
		ports[1] = dPort;
		
		
		message = ports[0] + " " + ports[1] + " " + message;
		
		
		// calls the method to create the checksum
		createChecksum(message);
		
		return message;
		
	}

	// Need to rework these to add to a DatagramPacket to create for a UDP application
	public String sendData(int destNode, String message) throws IOException {

		// Create header for transport layer: sourceport, destport, length, checksum, message
		
		int length;
		
		length = message.length();
		
		createHeader(message);
		createChecksum(message);
		
		msg.setData(message.getBytes());
		NetworkLayer nl = new NetworkLayer(sourceNode, destNode, msg);
		nl.routingTable();
	
		//removeHeader(msg);

		return message;

	}
	
	public int createChecksum(String message) throws SocketException {

		int maxSize = 0;
		int length = msg.getLength();
		
		// set the maximum size of the data with the MTU's from the file
		for(Node node : Client.linkNode) {
			if(sourceNode == node.getNodeID()) {
				maxSize = node.getMtuBytes();
				transmissionBytes = maxSize;
			}
		}
		
		// array to hold the max size for the data being sent
		int data[] = new int[maxSize];
		
		// array to hold the max size for the compliment of the data
		int complimentData[] = new int[maxSize];
		
		int numBits = 0;
		checkSum = 0;
		int i = 0;
		
		for(byte b : msg.getData()) {
			
			data[i] = b;
		}
		
		i = 0;
		// creating the checksum for the length of data in the message
		for(i = 0; i < length; i++) {
			numBits = (int)(Math.floor(Math.log(data[i]) / Math.log(2))) + 1;
			
			// compliments the checksum
			complimentData[i] = ((1 << numBits) - 1) ^ data[i];
			
			// adding the complimented data
			checkSum += complimentData[i];
		}
		
		// creates the sum of the checksum
		data[i] = checkSum;
	
		// adds the checksum to the "header"
		message = message + " " + checkSum;		
		
		return checkSum;
	}
	
	public String removeHeader(DatagramPacket msg) {
		
		byte srcPort = (byte) sourcePort;
		byte dstPort = (byte) destPort;
		
		String newStr = new String(srcPort + " " + dstPort + " ");
		
		String str = new String(msg.getData());
		
		str = str.replaceAll(newStr, "");
		msg.setData(str.getBytes());
		
		System.out.println(str);
		
		return str;
	}
}
