import java.io.*;

public class Main {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
	
		Client client;
		
		if(args.length != 2)
			System.out.println("Usage: java Client host port");
		else 
			client = new Client(Integer.parseInt(args[0]), args[1]); // run as java Main (nodeID) (itc-[number])
		//java Main 1 itc-1
		
	}
}