import java.io.*;
import java.util.Scanner;
import java.util.zip.Adler32;

public class Transfer {

	int destPort, sourcePort;
	String message;
	
	public Transfer() {

	}

	public Transfer(int sourcePort, int destPort, String message) {
		super();
		this.sourcePort = sourcePort;
		this.destPort = destPort;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	// Need to rework these to add to a DatagramPacket to create for a UDP application
	public void sendData(int destNode, String message) throws IOException {

		// Create header for transport layer: sourceport, destport, length, checksum, message
		
		int length;
		
		byte sourceAddress, destAddress;
		int cksm;

		length = message.length();
		
		
		
		
		message = sourcePort + " " + destPort + " " + length + " " + message;
		
	//	byte[] data = message;
		
		//createChecksum(data);
		System.out.println(message);
		/*IPLayer ipLayer = new IPLayer(data.toString(), neighborOne, neighborTwo);
		ipLayer.sendData(destNode,neighborOne, neighborTwo, data.toString());*/
	}
	
	public void createChecksum(String data) {
		
		Adler32 checksum = null;
		
	//	checksum.up
	//	System.out.println(checksum);
	}
}
